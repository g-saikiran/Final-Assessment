from django.db import models

# Create your models here.
class Student(models.Model):
    name = models.CharField(max_length=35, null=True, blank=True)
    dob = models.DateField(null=True, blank=True)
    rollnum = models.CharField(max_length=40,primary_key=True)
    department = models.CharField(max_length=40, null=True, blank=True)
    address = models.CharField(max_length=100, null=True, blank=True)

class Teacher(models.Model):
    name = models.CharField(max_length=35, null=True, blank=True)
    Staffid = models.CharField(max_length=40,primary_key=True)
    department = models.CharField(max_length=40, null=True, blank=True)

class Questions(models.Model):
    Addaquestion = models.CharField(max_length=35, null=True, blank=True)
    

class Results(models.Model):
    firstlanguage = models.IntegerField(null=True, blank=True)
    secondlanguage = models.IntegerField(null=True, blank=True)
    thirdlanguage = models.IntegerField(null=True, blank=True)
    Total=models.IntegerField(null=True, blank=True)