from django.shortcuts import render, HttpResponseRedirect
from django.contrib import messages
from .forms import SignUpForm
from django.http import HttpResponse
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
from django.utils.dateparse import parse_duration
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import redirect
from .models import *
from django.contrib import messages 
from django.contrib.auth.models import User



#Signup
def sign_up(request):
    if request.method == "POST":
        frm = SignUpForm(request.POST)
        if frm.is_valid():
            frm.save()
            return HttpResponse("Student Created Successfully!!")
    else:
        frm = SignUpForm()
    return render(request,'signup.html',{'form':frm})


 
#Login
def user_login(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            fmr = AuthenticationForm(request=request,data=request.POST)
            if fmr.is_valid():
                uname = fmr.cleaned_data['username']
                upass = fmr.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Logged in successfully!!!')
                    return HttpResponseRedirect('/home/')
        else:
            fmr = AuthenticationForm()
        return render(request,'userlogin.html',{'form':fmr})
    else:
        return HttpResponseRedirect('/home/')
  

#Logout
def user_logout(request):
    logout(request)
    return HttpResponse("Logout Successful !!")

#ADDQUESTION
@login_required
@staff_member_required
def addquestion(request):
    if request.method == "POST":
        q = request.POST['question']
        add = Questions.objects.create(Addaquestion=q)
        messages.success(request, "Question Added successfully")
        return HttpResponse("Question Added Successfully")
    return render(request, 'addquestion.html')


#Showing the Questions
@login_required
def questionlist(request):
    questionsdata = Questions.objects.filter()
    ss = {'questions':questionsdata}
    return render(request, 'questionlist.html',ss)

@login_required
def home(request):
    return render(request, 'home.html',{})

@login_required
@staff_member_required
def results(request):
    add=Results.objects.all()
    sub={'result':add}
    return render(request,'results.html',sub)