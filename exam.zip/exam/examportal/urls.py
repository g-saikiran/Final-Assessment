from django.contrib import admin
from django.urls import path
from examportal import views


urlpatterns = [
    path('login/',views.user_login, name='login'),
    path('signup/',views.sign_up, name='signup'),
    path('logout/',views.user_logout,name='logout'),
    path('addquestion/',views.addquestion, name='addquestion'),
    path('showquestions/',views.questionlist, name='showquestion'),
    path('home/',views.home, name='home'),
    path('results/',views.results, name='results'),

]